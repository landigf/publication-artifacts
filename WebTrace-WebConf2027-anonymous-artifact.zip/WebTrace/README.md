# WebTrace anonymous review artifact

This package accompanies the anonymous WebTrace manuscript. It preserves the fixed numerical inputs and replay code from the evaluated snapshot. Identifying publication metadata and preparation-only tools are excluded.

## Reproduce offline

Use Python 3.12, install `requirements-lock.txt` in a virtual environment, then run:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-lock.txt
BROWSETRACE_PYTHON=.venv/bin/python sh REPRODUCE.sh
```

The verifier checks published file hashes, schemas, corpus denominators, cache-key opacity, source-projection consistency, credential-header removal, and simulator behavior. It reruns all six policies at five capacities for both workloads, compares numerical results, then regenerates figures and TeX inputs under `reports/reproduction/`. Model/API access and private raw bundles are unnecessary. Installation needs package downloads; execution uses local files only.

For a quick integrity check without the 60 replays: `.venv/bin/python tools/verify_publication.py`. The released figures are in `figures/`, generated manuscript numbers/tables in `reports/`, and complete results in `reports/public-cache-replay.json` and `reports/publication-statistics.json`.

## What is measured

The main census comprises 400 scripted attempts and 911 LLM attempts, including 98 zero-request attempts. A separate local comparison comprises 300 LLM attempts; its baseline is the 100 Zurich scripted attempts already inside the main corpus. Ten task observations performed by the author are a descriptive reference, not a population baseline. The author confirmed publication authority and consent for these observations; no ethical-review determination is claimed.

The main LLM mean is 392.7 recorded requests per attempt versus 420.2 for scripted browsing; excluding empty LLM attempts gives 440.1. Ratios of 3.324–4.166 occur only in the separate local comparison against the Zurich scripted mean of 148.3. Models, browser substrates, step budgets, geography and collection batches differ. These comparisons do not isolate model effects.

`data/traces/full_400_sessions.csv` has 82,455 positive-size replay rows; `llm_full_901.csv` has 357,782 rows, of which libCacheSim processes 236,073 positive-size rows. The LLM filename is historical: the census establishes 911 attempts, and its 100 repeated legacy session labels cannot identify models or regions per replay row. The CSV labels and census IDs are separate namespaces and must not be joined.

Cache results use cold caches, stored row order, default libCacheSim settings, and MiB capacities. This is an object-cache experiment; it does not implement HTTP Cache-Control, freshness, Vary or authenticated cache eligibility, and does not measure network latency or serving throughput. Request and byte hit ratios are different objectives: at 5 MiB scripted GDSF beats LRU on request hits (59.5% versus 37.4%) but loses on byte hits (15.8% versus 24.9%). S3-FIFO has higher byte hits than both.

## Provenance and privacy

Entire cache keys are opaque one-to-one HMAC tokens, not URLs. The shared ephemeral secret was discarded. Source-to-export equality and preserved field sequences were verified during export; all 60 source/released replay results agree exactly in the pinned implementation. See `reports/input-transformation.json` and `reports/opaque-replay-equivalence.json`. These reports record the preparation-time comparison; original private inputs are not released.

The released census and liveness-count CSVs are sanitized projections of retained historical summaries/traces. Every retained numerical claim is recomputed from those projections; this does not independently establish collection authenticity or semantic task success. Raw session bundles, HTTP headers/bodies, original keys/identifiers, and secrets are omitted. Hash inventories cover the explicit release files.

`collection/` and `schema/` retain the public collection implementation and task definitions for inspection. The import paths were repaired for this artifact layout and credential header fields are removed from request/response exports. This historical code is separate from offline reproduction; exact historical browser/model dependencies are unavailable, and rerunning it would collect a new live-web workload. No new collection was performed.


Code: Apache-2.0 (LICENSE). Data: CC BY 4.0 (LICENSE-DATA). Author identity and contact are withheld for anonymous review. The paper license is separate. The opaque keys are already fixed; do not regenerate them. Offline replay needs no provider or model calls. Collection code is supplied for inspection and is not executed by REPRODUCE.sh.
